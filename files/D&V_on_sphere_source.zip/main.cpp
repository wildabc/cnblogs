#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/convex_hull_3.h>
#include <CGAL/Polyhedron_3.h>

#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef K::Point_2 Point2;
typedef K::Point_3 Point3;
typedef K::Vector_3 Vector3;
typedef CGAL::Polygon_2<K> Polygon_2;
typedef CGAL::Polyhedron_3<K> Polyhedron_3;
typedef std::vector<Point2> Polygon;

struct Plane_equation {
    template <class Facet>
    typename Facet::Plane_3 operator()( Facet& f) {
        typename Facet::Halfedge_handle h = f.halfedge();
        typedef typename Facet::Plane_3  Plane;
	typedef typename K::Vector_3  Vector;

        Plane plane = Plane( h->vertex()->point(),
                      h->next()->vertex()->point(),
                      h->next()->next()->vertex()->point());
	Vector vec = plane.orthogonal_vector();
	vec = vec/sqrt(vec.squared_length());
	return Plane(h->vertex()->point(),vec);
	/*
	return Plane( h->vertex()->point(),
                      h->next()->vertex()->point(),
                      h->next()->next()->vertex()->point());
	*/
    }
};

inline double A2D(double a)
{
	return a/M_PI*180;
}

inline double D2A(double d)
{
	return d/180*M_PI;
}

//Point On Sphere to Longitude and Latitude
inline void POS2LL(double x , double y , double z , double& lo , double& la)
{
	double r = sqrt(x*x + y*y + z*z);
	la = A2D(asin(z/r));	
	lo = A2D(atan2(y , x));
}

int main()
{
	std::ifstream f;
	std::vector<Polygon> polygons;
	std::vector<Point3> points3d;
	Polyhedron_3 hull;

	Point2 p2;
	Point3 p3;

	polygons.reserve(4);
	for(int i = 1 ; i < 5 ; i++)
	{
		std::ostringstream s;
		s<<"2d"<<i<<".txt";
		f.open(s.str().c_str());

		Polygon points2d;
		while(f>>p2)
		{
			points2d.push_back(p2);
			K::FT t = cos(D2A(p2[1]));
			p3 = Point3(t*cos(D2A(p2[0])),t*sin(D2A(p2[0])),sin(D2A(p2[1])));
			points3d.push_back(p3);
		}
		polygons.push_back(points2d);
		std::cout<<points2d.size()<<std::endl;

		f.close();
	}

	CGAL::convex_hull_3(points3d.begin(), points3d.end(), hull);

	std::transform( hull.facets_begin(), hull.facets_end(), hull.planes_begin(),
                    Plane_equation());
	

	/*
	for(Polyhedron_3::Plane_iterator i = hull.planes_begin() ; i != hull.planes_end() ; i++)
	{
		Vector3 vec = i->orthogonal_vector();
		double lo,la;
		POS2LL(vec.x(),vec.y(),vec.z(),lo,la);
		//std::cout<<lo<<"\t"<<la<<std::endl;
		std::cout<<CGAL::bounded_side_2(points2d.begin(),points2d.end(),Point2(lo,la),K())<<std::endl;
	}
	*/

	std::ofstream fout("./test.kml");

	fout<<"<?xml version=\"1.0\" encoding=\"UTF-8\"?>"<<std::endl;
	fout<<"<kml xmlns=\"http://www.opengis.net/kml/2.2\">"<<std::endl;
	fout<<"<Document>"<<std::endl;

	fout<<"<Style id=\"RedLine\">"<<std::endl;
	fout<<"<LineStyle>"<<std::endl;
	fout<<"<color>ff0000ff</color>"<<std::endl;
	fout<<"<width>2</width>"<<std::endl;
	fout<<"</LineStyle>"<<std::endl;
	fout<<"</Style>"<<std::endl;

	fout<<"<Style id=\"BlueLine\">"<<std::endl;
	fout<<"<LineStyle>"<<std::endl;
	fout<<"<color>ffff0000</color>"<<std::endl;
	fout<<"<width>2</width>"<<std::endl;
	fout<<"</LineStyle>"<<std::endl;
	fout<<"</Style>"<<std::endl;

	fout<<"<Style id=\"GreenLine\">"<<std::endl;
	fout<<"<LineStyle>"<<std::endl;
	fout<<"<color>ff00ff00</color>"<<std::endl;
	fout<<"<width>2</width>"<<std::endl;
	fout<<"</LineStyle>"<<std::endl;
	fout<<"</Style>"<<std::endl;	

	fout<<"<Placemark>"<<std::endl;
	fout<<"<name>Delaunay triangles</name>"<<std::endl;
	fout<<"<styleUrl>#RedLine</styleUrl>"<<std::endl;
	fout<<"<MultiGeometry>"<<std::endl;

	for(Polyhedron_3::Edge_iterator i = hull.edges_begin() ; i != hull.edges_end() ; i++)
	{
		Point3 p0,p1;
		double lo,la;

		p0 = i->vertex()->point();
		p1 = i->opposite()->vertex()->point();
		
		Vector3 vec(CGAL::ORIGIN,CGAL::midpoint(p0,p1));
		if(i->facet()->plane().orthogonal_vector()*vec<0 &&
			i->opposite()->facet()->plane().orthogonal_vector()*vec<0)
		{
			continue;
		}

		fout<<"<LineString>"<<std::endl;
		fout<<"<tessellate>1</tessellate>"<<std::endl;
		fout<<"<coordinates>"<<std::endl;

		POS2LL(p0.x(),p0.y(),p0.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;
		
		POS2LL(p1.x(),p1.y(),p1.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;

		fout<<"</coordinates>"<<std::endl;
		fout<<"</LineString>"<<std::endl;
	}

	fout<<"</MultiGeometry>"<<std::endl;
	fout<<"</Placemark>"<<std::endl;

	//////////////////////////////////////////
	fout<<"<Placemark>"<<std::endl;
	fout<<"<name>Voronoi diagram</name>"<<std::endl;
	fout<<"<styleUrl>#BlueLine</styleUrl>"<<std::endl;
	fout<<"<MultiGeometry>"<<std::endl;

	for(Polyhedron_3::Edge_iterator i = hull.edges_begin() ; i != hull.edges_end() ; i++)
	{
		Point3 p0,p1,mp;
		double lo,la;

		p0 = CGAL::ORIGIN+i->facet()->plane().orthogonal_vector();
		p1 = CGAL::ORIGIN+i->opposite()->facet()->plane().orthogonal_vector();
		mp = CGAL::midpoint(p0,p1);
		
		fout<<"<LineString>"<<std::endl;
		fout<<"<tessellate>1</tessellate>"<<std::endl;
		fout<<"<coordinates>"<<std::endl;

		POS2LL(p0.x(),p0.y(),p0.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;

		POS2LL(mp.x(),mp.y(),mp.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;
		
		POS2LL(p1.x(),p1.y(),p1.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;

		fout<<"</coordinates>"<<std::endl;
		fout<<"</LineString>"<<std::endl;
	}
	fout<<"</MultiGeometry>"<<std::endl;
	fout<<"</Placemark>"<<std::endl;

	//////////////////////////////////////////
	fout<<"<Placemark>"<<std::endl;
	fout<<"<name>Medial axis</name>"<<std::endl;
	fout<<"<styleUrl>#GreenLine</styleUrl>"<<std::endl;
	fout<<"<MultiGeometry>"<<std::endl;


	for(Polyhedron_3::Edge_iterator i = hull.edges_begin() ; i != hull.edges_end() ; i++)
	{
		Point3 p0,p1,mp;
		double lo,la;


		p0 = CGAL::ORIGIN+i->facet()->plane().orthogonal_vector();
		p1 = CGAL::ORIGIN+i->opposite()->facet()->plane().orthogonal_vector();

		int j;
		POS2LL(p0.x(),p0.y(),p0.z(),lo,la);
		for(j = 0 ; j < 4 ; j++)
		{
			if(CGAL::bounded_side_2(polygons[j].begin(), polygons[j].end(),Point2(lo,la), K()) == CGAL::ON_BOUNDED_SIDE)
			{
				break;
			}
		}
		
		if(j == 4)
		{
			continue;
		}

		POS2LL(p1.x(),p1.y(),p1.z(),lo,la);
		if(CGAL::bounded_side_2(polygons[j].begin(), polygons[j].end(),Point2(lo,la), K()) == CGAL::ON_UNBOUNDED_SIDE)
		{
			continue;
		}

		mp = CGAL::midpoint(p0,p1);

		fout<<"<LineString>"<<std::endl;
		fout<<"<tessellate>1</tessellate>"<<std::endl;
		fout<<"<coordinates>"<<std::endl;

		POS2LL(p0.x(),p0.y(),p0.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;

		POS2LL(mp.x(),mp.y(),mp.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;
		
		POS2LL(p1.x(),p1.y(),p1.z(),lo,la);
		fout<<lo<<","<<la<<std::endl;

		fout<<"</coordinates>"<<std::endl;
		fout<<"</LineString>"<<std::endl;
	}
	fout<<"</MultiGeometry>"<<std::endl;
	fout<<"</Placemark>"<<std::endl;

	Polyhedron_3::Facet_handle in_fh;
	double in_max_d = 0;
	Polyhedron_3::Facet_handle out_fh;
	double out_max_d = 0;
	for(Polyhedron_3::Facet_iterator i = hull.facets_begin() ; i != hull.facets_end() ; i++)
	{
		Vector3 vec = i->plane().orthogonal_vector();
		double lo,la;
		POS2LL(vec.x(),vec.y(),vec.z(),lo,la);
		double d = (i->plane().orthogonal_vector()-Vector3(CGAL::ORIGIN,i->halfedge()->vertex()->point())).squared_length();

		if(CGAL::bounded_side_2(polygons[3].begin(), polygons[3].end(),Point2(lo,la), K()) == CGAL::ON_UNBOUNDED_SIDE)
		{
			if(d>out_max_d)
			{
				out_fh = i;
				out_max_d = d;
			}
		}
		else
		{
			if(d>in_max_d)
			{
				in_fh = i;
				in_max_d = d;
			}
		}
	}

	std::cout<<"Internal longest distance:"<<sqrt(in_max_d)<<std::endl;
	std::cout<<"External longest distance:"<<sqrt(out_max_d)<<std::endl;

	Vector3 farthest;
	double lo,la;

	fout<<"<Placemark>"<<std::endl;
	fout<<"<name>Internal farthest point</name>"<<std::endl;
	farthest = in_fh->plane().orthogonal_vector();
	POS2LL(farthest.x(),farthest.y(),farthest.z(),lo,la);
	fout<<"<Point>"<<std::endl;
	fout<<"<coordinates>"<<std::endl;
	fout<<lo<<","<<la<<std::endl;
	fout<<"</coordinates>"<<std::endl;
	fout<<"</Point>"<<std::endl;
	fout<<"</Placemark>"<<std::endl;

	fout<<"<Placemark>"<<std::endl;
	fout<<"<name>External farthest point</name>"<<std::endl;
	farthest = out_fh->plane().orthogonal_vector();
	POS2LL(farthest.x(),farthest.y(),farthest.z(),lo,la);
	fout<<"<Point>"<<std::endl;
	fout<<"<coordinates>"<<std::endl;
	fout<<lo<<","<<la<<std::endl;
	fout<<"</coordinates>"<<std::endl;
	fout<<"</Point>"<<std::endl;
	fout<<"</Placemark>"<<std::endl;

	fout<<"</Document>"<<std::endl;
	fout<<"</kml>"<<std::endl;

	fout.close();

	return 0;
}
