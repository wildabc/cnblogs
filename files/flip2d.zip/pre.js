var args = window.location.search.substring(1);
if(args)
	Module.arguments = args.split("&");
