int vasprintf( char **sptr, const char *fmt, va_list argv );
