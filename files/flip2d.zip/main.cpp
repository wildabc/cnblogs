#include <cstdio>
#include <cstdlib>
#include "particles.h"
#include "util.h"
#include "gluvi.h"
//#define TIME
#ifdef TIME
  #include <ctime>
#endif

using namespace std;

int grid_size = 50;
float frame_time = 1./30;
unsigned int frame = 0;
char frame_number[100]="frame 0";
Grid* p_grid;
Particles* p_particles;

const unsigned int cases = 8;
int init_case = 5;

float fluidphi(Grid &grid, float x, float y)
{
	switch(init_case){
		case 0:
			return y-0.5*grid.ly;
		case 1:
			return min(sqrt(sqr(x-0.5*grid.lx)+sqr(y-0.625*grid.ly))-0.02*grid.ly, y-0.6*grid.ly);
		case 2:
			return min(sqrt(sqr(x-0.3333*grid.lx)+sqr(y-0.71*grid.ly))-0.3*grid.ly, y-0.2*grid.ly);
		case 3:
			return max(y-0.8*grid.ly, -sqrt(sqr(x-0.5*grid.lx)+sqr(y-0.2*grid.ly))+0.1*grid.lx);
		case 4:
			return sqrt(sqr(x-0.5*grid.lx)+sqr(y-0.75*grid.ly))-0.15*grid.lx;
		case 5:
		default:
			return min(y-0.05*grid.ly, sqrt(sqr(x-0.5*grid.lx)+sqr(y-0.5*grid.ly))-0.05*grid.lx);
		case 6:
			return 0.75*grid.lx-x;
		case 7:
			return max(max(x-0.75*grid.lx, 0.25*grid.lx-x), max(y-0.75*grid.ly, 0.25*grid.ly-y));
	}
}

void project(Grid &grid, float &x, float &y, float current, float target)
{
   float dpdx=(fluidphi(grid, x+1e-4, y)-fluidphi(grid, x-1e-4, y))/2e-4;
   float dpdy=(fluidphi(grid, x, y+1e-4)-fluidphi(grid, x, y-1e-4))/2e-4;
   float scale=(target-current)/sqrt(dpdx*dpdx+dpdy*dpdy);
   x+=scale*dpdx;
   y+=scale*dpdy;
}

void init_water_drop(Grid &grid, Particles &particles, int na, int nb)
{
   int i, j, a, b;
   float x, y, phi;

   for(i=1; i<grid.marker.nx-1; ++i){
      for(j=1; j<grid.marker.ny-1; ++j){
         for(a=0; a<na; ++a){
            for(b=0; b<nb; ++b){
               x=(i+(a+0.1+0.8*rand()/(double)RAND_MAX)/na)*grid.h;
               y=(j+(b+0.1+0.8*rand()/(double)RAND_MAX)/nb)*grid.h;
               phi=fluidphi(grid, x, y);
               if(phi>-0.25*grid.h/na)
                  continue;
               else if(phi>-1.5*grid.h/na){
                  project(grid, x, y, phi, -0.75*grid.h/na);
                  phi=fluidphi(grid, x, y);
                  project(grid, x, y, phi, -0.75*grid.h/na);
                  phi=fluidphi(grid, x, y);
               }
               particles.add_particle(Vec2f(x,y), Vec2f(0,0));
            }
         }
      }
   }
}

void advance_one_step(Grid &grid, Particles &particles, double dt)
{
   for(int i=0; i<5; ++i)
      particles.move_particles_in_grid(0.2*dt);
   particles.transfer_to_grid();
   //grid.save_velocities();
   grid.add_gravity(dt);
   grid.compute_distance_to_fluid();
   grid.extend_velocity();
   grid.apply_boundary_conditions();
   grid.make_incompressible();
   grid.extend_velocity();
   //grid.get_velocity_update();
   particles.update_from_grid();
}

void advance_one_frame(Grid &grid, Particles &particles, double frame_time)
{
   double t=0;
   double dt;
   bool finished=false;
   while(!finished){
      dt=2*grid.CFL();
      if(t+dt>=frame_time){
         dt=frame_time-t;
         finished=true;
      }else if(t+1.5*dt>=frame_time)
         dt=0.5*(frame_time-t);
      printf("advancing %g (to %f%% of frame)\n", dt, 100*(t+dt)/frame_time);
      advance_one_step(grid, particles, dt);
      t+=dt;
   }
}

void display(void)
{
   glDisable(GL_LIGHTING);
   glColor3f(1, 1, 1);
   glBegin(GL_POINTS);
   for(unsigned int i=0; i<p_particles->x.size(); ++i)
      glVertex2fv(p_particles->x[i].v);
   glEnd();
}

struct ScreenShotButton : public Gluvi::Button{
   const char *filename_format;
   ScreenShotButton(const char *label, const char *filename_format_) : Gluvi::Button(label), filename_format(filename_format_) {}
   void action()
   { Gluvi::ppm_screenshot(filename_format, frame); }
};

void special_key_handler(int key, int x, int y)
{
   switch(key){
      case GLUT_KEY_RIGHT:
		  frame++;
		  sprintf(frame_number, "frame %d", frame);
		  advance_one_frame(*p_grid, *p_particles, frame_time);
		  glutPostRedisplay();
		  return;
	  case GLUT_KEY_UP:
		  init_case = (init_case+1) % cases;
		  break;
	  case GLUT_KEY_DOWN:
		  init_case = (init_case-1) % cases;
		  break;
      case GLUT_KEY_LEFT:
		  break;
      default:
         ;
   }

   frame = 0;
   sprintf(frame_number, "frame %d", frame);
   delete p_grid;
   delete p_particles;
   p_grid = new Grid(9.8, grid_size, grid_size, 1);
   p_particles = new Particles(*p_grid);
   init_water_drop(*p_grid, *p_particles, 2, 2);
   glutPostRedisplay();
}

int main(int argc, char **argv)
{
   if(argc > 1){
	   grid_size = atoi(argv[1]);
   }
   if(argc > 2){
	   frame_time = 1./atoi(argv[2]);
   }

   p_grid = new Grid(9.8, grid_size, grid_size, 1);
   p_particles = new Particles(*p_grid);

   init_water_drop(*p_grid, *p_particles, 2, 2);

#ifdef TIME
   clock_t begin = clock();
   for(int i=1; i<101; ++i){
      printf("===================================================> step %d...\n", i);
      advance_one_frame(*p_grid, *p_particles, frame_time);
   }
   clock_t end = clock();
   printf("Total Time: %f\n", (float)(end-begin)/CLOCKS_PER_SEC);
#else
   Gluvi::init("flip2d", &argc, argv);

   Gluvi::PanZoom2D cam(0, 0, 1);
   Gluvi::camera=&cam;

   glutSpecialFunc(special_key_handler);
   Gluvi::userDisplayFunc=display;

#ifndef EMSCRIPTEN
   Gluvi::StaticText frametext(frame_number);
   Gluvi::root.list.push_back(&frametext);

   ScreenShotButton screenshot("Screenshot", "%04d.ppm");
   Gluvi::root.list.push_back(&screenshot);
#endif

   printf("Use arrow keys to control.\n");
   printf("Right: step forward.\n");
   printf("Left: go back to beginning.\n");
   printf("Up: switch to next scene.\n");
   printf("Down: switch to previous scene.\n");

   Gluvi::run();
#endif

   delete p_grid;
   delete p_particles;
   return 0;
}
