#include <stdio.h>
#include <stdlib.h>
#include "array2.h"
extern "C" {
#include "ldl.h"
}
#define USE_AMD
#ifdef USE_AMD
#include "amd.h"
#endif

/* ---------Macros from ldl demo--------------------------------------------- */
/* -------------------------------------------------------------------------- */
/* ALLOC_MEMORY: allocate a block of memory */
/* -------------------------------------------------------------------------- */

#define ALLOC_MEMORY(p,type,size) \
p = (type *) calloc ((((size) <= 0) ? 1 : (size)) , sizeof (type)) ; \
if (p == (type *) NULL) \
{ \
    printf ("out of memory\n") ; \
    exit(1) ; \
}

/* -------------------------------------------------------------------------- */
/* FREE_MEMORY: free a block of memory */
/* -------------------------------------------------------------------------- */

#define FREE_MEMORY(p,type) \
if (p != (type *) NULL) \
{ \
    free (p) ; \
    p = (type *) NULL ; \
}

void ldlsolve(const Array2x3f& poisson, const Array2d& r, Array2d& pressure){
	int n = 0, Anz = 0, p=0, c=0;
	int *Ap, *Ai, *Lp, *Li, *Parent, *Lnz, *Flag, *Pattern, *P, *Pinv;
	double *Ax, *Lx, *D, *Y, *b, *x;
	Array2<int> indices(poisson.nx, poisson.ny);

	for(int j=0; j<indices.ny; ++j) for(int i=0; i<indices.nx; ++i){
		indices(i,j) = -1;
	}
	for(int j=1; j<indices.ny-1; ++j) for(int i=1; i<indices.nx-1; ++i){
		if(poisson(i,j,0)>0){
			indices(i,j) = n++;
			Anz += (poisson(i,j,1)<0) + (poisson(i,j,2)<0);
		}
	}
	Anz = Anz*2+n;

	ALLOC_MEMORY(Ap, int, n+1);
	ALLOC_MEMORY(Ai, int, Anz);
	ALLOC_MEMORY(Ax, double, Anz);
	ALLOC_MEMORY(b, double, n);
	ALLOC_MEMORY(x, double, n);

	for(int j=1; j<indices.ny-1; ++j) for(int i=1; i<indices.nx-1; ++i){
		if(indices(i,j)>=0){
			Ap[c] = p;
			b[c++] = r(i,j);

			if(indices(i,j-1)>=0){
				Ai[p] = indices(i,j-1);
				Ax[p++] = -1;
			}
			if(indices(i-1,j)>=0){
				Ai[p] = indices(i-1,j);
				Ax[p++] = -1;
			}
			Ai[p] = indices(i,j);
			Ax[p++] = poisson(i,j,0);
			if(indices(i+1,j)>=0){
				Ai[p] = indices(i+1,j);
				Ax[p++] = -1;
			}
			if(indices(i,j+1)>=0){
				Ai[p] = indices(i,j+1);
				Ax[p++] = -1;
			}
		}
	}
	Ap[n] = Anz;

	ALLOC_MEMORY(Parent, int, n);
	ALLOC_MEMORY(Lnz, int, n);
	ALLOC_MEMORY(Flag, int, n);
	ALLOC_MEMORY(Lp, int, n+1);
	ALLOC_MEMORY(Pattern, int, n);
	ALLOC_MEMORY(P, int, n);
	ALLOC_MEMORY(Pinv, int, n);
	ALLOC_MEMORY(D, double, n);
	ALLOC_MEMORY(Y, double, n);

#ifdef USE_AMD
	amd_order(n, Ap, Ai, P, NULL, NULL);
	ldl_symbolic(n, Ap, Ai, Lp, Parent, Lnz, Flag, P, Pinv);
#else
	ldl_symbolic(n, Ap, Ai, Lp, Parent, Lnz, Flag, NULL, NULL);
#endif
	ALLOC_MEMORY(Li, int, Lp[n]);
	ALLOC_MEMORY(Lx, double, Lp[n]);
#ifdef USE_AMD
	ldl_numeric(n, Ap, Ai, Ax, Lp, Parent, Lnz, Li, Lx, D, Y, Flag, Pattern, P, Pinv);
#else
	ldl_numeric(n, Ap, Ai, Ax, Lp, Parent, Lnz, Li, Lx, D, Y, Flag, Pattern, NULL, NULL);
#endif

#ifdef USE_AMD
	ldl_perm(n, Y, b, P);
	ldl_lsolve(n, Y, Lp, Li, Lx);
	ldl_dsolve(n, Y, D);
	ldl_ltsolve(n, Y, Lp, Li, Lx);
	ldl_permt(n, x, Y, P);
#else
	for(int i=0; i<n; ++i){
		x[i] = b[i];
	}
	ldl_lsolve(n, x, Lp, Li, Lx);
	ldl_dsolve(n, x, D);
	ldl_ltsolve(n, x, Lp, Li, Lx);
#endif

	c = 0;
	pressure.zero();
	for(int j=1; j<indices.ny-1; ++j) for(int i=1; i<indices.nx-1; ++i){
		if(indices(i,j)>=0){
			pressure(i,j) = x[c++];
		}
	}

	FREE_MEMORY(Ap, int);
	FREE_MEMORY(Ai, int);
	FREE_MEMORY(Ax, double);
	FREE_MEMORY(b, double);
	FREE_MEMORY(x, double);
	FREE_MEMORY(Parent, int);
	FREE_MEMORY(Lnz, int);
	FREE_MEMORY(Flag, int);
	FREE_MEMORY(Lp, int);
	FREE_MEMORY(Pattern, int);
	FREE_MEMORY(P, int);
	FREE_MEMORY(Pinv, int);
	FREE_MEMORY(D, double);
	FREE_MEMORY(Y, double);
	FREE_MEMORY(Li, int);
	FREE_MEMORY(Lx, double);
}
