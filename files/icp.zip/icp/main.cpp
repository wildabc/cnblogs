#include <ANN/ANN.h>

#include <Eigen/Dense>
using namespace Eigen;

#include <vector>
#include <fstream>
#include <time.h>
using namespace std;

#include "methods.h"

inline Matrix3d EulerAnglesZXZ(const Vector3d& a)
{
  Matrix3d R = (AngleAxisd(a(0),Vector3d::UnitZ())
      		*AngleAxisd(a(1),Vector3d::UnitX())
      		*AngleAxisd(a(2),Vector3d::UnitZ()))
    		.toRotationMatrix();
  return R;
}

int main(int argc, char** argv)
{
  vector<vector<double> > data;
  unsigned max_iter;
  VectorXd transf(6);

  if(argc >= 2)
  {
    max_iter = atoi(argv[1]);
  }

  ifstream in("data/points.xyz");
  if(!in)
  {
    cerr<<"Cannot read points!"<<endl;
    return EXIT_FAILURE;
  }
  while(true)
  {
    bool valid = true;
    vector<double> line(6);
    for(int j = 0 ; j < 6 ; j++)
    {
      if(!(in>>line[j])) 
      {
	valid = false;
	break;
      }
    }

    if(!valid) break;

    data.push_back(line);
  }
  cout<<"Number of points:"<<data.size()<<endl;

  ifstream inf("data/transform.txt");
  if(!inf)
  {
    cerr<<"Cannot read transform!"<<endl;
    return EXIT_FAILURE;
  }

  transf.setZero();
  for(int i = 0 ; i < 6 ; i++)
  {
    if(!(inf>>transf(i))) break;
  }

  ANNpointArray dataPts = annAllocPts(data.size(), 3);

  for(int i = 0 ; i < data.size() ; i++)
  {
    ANNpoint dp = dataPts[i];
    vector<double> line = data[i];

    for(int j = 0 ; j < 3 ; j++)
    {
      dp[j] = line[j];
    }
  }

  ANNkd_tree* kdtree = new ANNkd_tree(dataPts, data.size(), 3);

  int mp_size = data.size();
  MatrixXd B(3,mp_size);
  for(int i = 0 ; i < mp_size ; i++)
  {
    for(int j = 0 ; j < 3 ; j++)
    {
      B(j,i) = dataPts[i][j];
    }
  }

  Matrix3d ini_R = EulerAnglesZXZ(transf.start(3));
  Vector3d ini_t = transf.segment(3,3);
  B = ini_R*B;
  B.colwise() += ini_t;


  ofstream out("result.txt");
  unsigned iter = 0;
  while(true)
  {
    ANNidx* nidx = new ANNidx[mp_size];
    ANNdist* ndist = new ANNdist[mp_size];
    ANNpoint query = annAllocPt(3);

    double absSum = 0;
    double squaredSum = 0;
    double max_d = 0;

    for(int i = 0 ; i < mp_size ; i++)
    {
      for(int j = 0 ; j < 3 ; j++)
      {
	query[j] = B(j,i);
      }

      kdtree->annkSearch(query,1,&nidx[i],&ndist[i]);

      double d = sqrt(ndist[i]);
      absSum += d;
      squaredSum += ndist[i];
      if(d>max_d)
      {
	max_d = d;
      }
    }

    cout<<"RMS:"<<sqrt(squaredSum/mp_size)<<endl;
    out<<absSum/mp_size<<"\t"<<sqrt(squaredSum/mp_size)<<"\t"<<max_d<<endl;

    if(argc < 3)
    {
      break;
    }

    if(iter >= max_iter)
    {
      delete [] nidx;
      delete [] ndist;
      annDeallocPt(query);

      break;
    }

    MatrixXd A(3,mp_size);
    MatrixXd N(3,mp_size);
    for(int i = 0 ; i < mp_size ; i++)
    {
      for(int j = 0 ; j < 3 ; j++)
      {
	A(j,i) = dataPts[nidx[i]][j];
	N(j,i) = data[nidx[i]][j+3];
      }
    }

    Matrix3d R;
    Vector3d t;
    
    clock_t t0 = clock();
    if(strcmp(argv[2],"p2") == 0)
    {
      PointL2(A,B,R,t);
    }
    else if(strcmp(argv[2],"p2t") == 0)
    {
      PointL2T(A,B,R,t);
    }
    else if(strcmp(argv[2],"p1") == 0)
    {
      PointL1(A,B,R,t);
    }
    else if(strcmp(argv[2],"pi") == 0)
    {
      PointLi(A,B,R,t);
    }
#ifdef MOSEK
    else if(strcmp(argv[2],"p1m") == 0)
    {
      PointL1M(A,B,R,t);
    }
    else if(strcmp(argv[2],"pim") == 0)
    {
      PointLiM(A,B,R,t);
    }
#endif
    else if(strcmp(argv[2],"prw") == 0)
    {
      if(argc == 4)
      {
	PointRW(atof(argv[3]),A,B,R,t);
      }
      else
      {
	break;
      }
    }
    else if(strcmp(argv[2],"prwt") == 0)
    {
      if(argc == 4)
      {
	PointRWT(atof(argv[3]),A,B,R,t);
      }
      else
      {
	break;
      }
    }
    else if(strcmp(argv[2],"p1h") == 0)
    {
      if(argc == 4)
      {
	PointL1H(atof(argv[3]),A,B,R,t);
      }
      else
      {
	break;
      }
    }
    ///////////////////////////////////////
    else if(strcmp(argv[2],"pl2") == 0)
    {
      PlaneL2(A,N,B,R,t);
    }
    else if(strcmp(argv[2],"pl1") == 0)
    {
      PlaneL1(A,N,B,R,t);
    }
    else if(strcmp(argv[2],"pli") == 0)
    {
      PlaneLi(A,N,B,R,t);
    }
#ifdef MOSEK
    else if(strcmp(argv[2],"pl1m") == 0)
    {
      PlaneL1M(A,N,B,R,t);
    }
    else if(strcmp(argv[2],"plim") == 0)
    {
      PlaneLiM(A,N,B,R,t);
    }
#endif
    else if(strcmp(argv[2],"plrw") == 0)
    {
      if(argc == 4)
      {
	PlaneRW(atof(argv[3]),A,N,B,R,t);
      }
      else
      {
	break;
      }
    }
    else if(strcmp(argv[2],"pl1h") == 0)
    {
      if(argc == 4)
      {
	PlaneL1H(atof(argv[3]),A,N,B,R,t);
      }
      else
      {
	break;
      }
    }
    else
    {
      break;
    }
    clock_t t1 = clock();
    cout<<"Time:"<<(double)(t1-t0)/CLOCKS_PER_SEC<<endl;
    //cout<<"R:"<<endl<<R<<endl<<"t:"<<endl<<t<<endl;

    B = R*B;
    B.colwise() += t;

    iter++;
  }

  out.close();

  delete kdtree;
  annDeallocPts(dataPts);
  annClose();

  return EXIT_SUCCESS;
}
