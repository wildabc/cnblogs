#include <Eigen/Dense>
#include <unsupported/Eigen/MatrixFunctions>
using namespace Eigen;

#include <glpk.h>
#include <lbfgs.h>

#ifdef MOSEK
#include <mosek.h>
#endif

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

#include "methods.h"

//Two classes for writing SDPA-Sparse file
class SparseSymMatrix
{
  public:
    int nnz;
    vector<int> iindices;
    vector<int> jindices;
    vector<double> entries;

    SparseSymMatrix(int n)
    {
      nnz = n;
      iindices.resize(n);
      jindices.resize(n);
      entries.resize(n);
    }

    void toString(int k, char* buf) const
    {
      sprintf(buf,"%d %d %.18e",iindices[k],jindices[k],entries[k]);
    }
};

class SDPASparse
{
  public:
    int varnum;
    int blocknum;
    vector<int> blockstruct;
    vector<double> object;
    typedef pair<int,SparseSymMatrix> BlockMatrix;
    typedef vector<BlockMatrix> BlockSparseMatrix;
    vector<BlockSparseMatrix> matices;

    void write(const char* filename) const
    {
      ofstream fout(filename);

      fout<<varnum<<endl;
      fout<<blocknum<<endl;

      for(int i = 0 ; i < blockstruct.size() ; i++)
      {
	fout<<blockstruct[i]<<" ";
      }
      fout<<endl;

      for(int i = 0 ; i < object.size() ; i++)
      {
	fout<<object[i]<<" ";
      }
      fout<<endl;

      char buf[50];
      for(int i = 0 ; i < matices.size() ; i++)
      {
	BlockSparseMatrix spmat = matices[i];
	for(int j = 0 ; j < spmat.size() ; j++)
	{
	  BlockMatrix block = spmat[j];
	  SparseSymMatrix mat = block.second;
	  for(int k = 0 ; k < mat.nnz ; k++)
	  {
	    mat.toString(k,buf);
	    fout<<i<<" "<<block.first<<" "<<buf<<endl;
	  }
	}
      }

      fout.close();
    }

    static vector<double> readCSDPSol(const char* filename, int numvar)
    {
      ifstream fin(filename);
      vector<double> res(numvar);
      for(int i = 0 ; i < numvar ; i++)
      {
	fin>>res[i];
      }

      return res;
    }
};

#ifdef MOSEK
static void MSKAPI printstr ( void * handle ,
    char str [])
{
  ofstream out("mosek.log",ios_base::app);
  out<<str;
  out.close();  
} /* printstr */
#endif

//A cross product between two vectors can be rewritten as the product of a skew-symmetric matrix and a vector. Here is the skew matrix.
inline Matrix3d cross2Skew(const Vector3d& v)
{
  Matrix3d skew = Matrix3d::Zero();
  skew(0,1) = -v(2);
  skew(0,2) =  v(1);
  skew(1,2) = -v(0);
  skew -= skew.transpose();

  return skew;
}

//Construct a rotation from infinitesimal rotation.
Matrix3d IR2R(const Vector3d& ir)
{
  Matrix3d skew = cross2Skew(ir);
  Matrix3d R;
  ei_matrix_exponential(skew,&R);

  return R;
}

struct HuberParam
{
  MatrixXd A,B,N;
  double EPSILON;
  enum{POINT,PLANE} TYPE;
  bool VERBOSE;
}HUBERPARAM;

static lbfgsfloatval_t evaluateHuber(
    void *instance,
    const lbfgsfloatval_t *x,
    lbfgsfloatval_t *grad,
    const int nvar,
    const lbfgsfloatval_t step
    )
{
  VectorXd delta(6);
  for(int i = 0 ; i < 6 ; i++)
  {
    delta(i) = x[i];
  }

  double EPSILON = HUBERPARAM.EPSILON;
  lbfgsfloatval_t fx = 0;
  VectorXd g = VectorXd::Zero(6);

  if(HUBERPARAM.TYPE == HuberParam::POINT)
  {
    MatrixXd A = HUBERPARAM.A;
    MatrixXd B = HUBERPARAM.B;
    int n = A.cols();
    double EPSILON2 = EPSILON*EPSILON;

    for(int i = 0 ; i < n ; i++)
    {
      Vector3d x = B.col(i);
      Vector3d y = A.col(i);
      Vector3d d = x-y;
      MatrixXd V(3,6);
      V.block(0,3,3,3) = Matrix3d::Identity();
      V.block(0,0,3,3) = -cross2Skew(x);

      Vector3d e = V*delta+d;
      double d2 = e.squaredNorm();

      if(d2 <= EPSILON2)
      {
	fx += d2/2/EPSILON;
	g += (V.transpose()*V*delta+V.transpose()*d)/EPSILON;
      }
      else
      {
	fx += sqrt(d2)-EPSILON/2;
	g += (V.transpose()*V*delta+V.transpose()*d)/sqrt(d2);
      }
    }
  }
  else
  {
    MatrixXd A = HUBERPARAM.A;
    MatrixXd B = HUBERPARAM.B;
    MatrixXd N = HUBERPARAM.N;
    int n = A.cols();

    for(int i = 0 ; i < n ; i++)
    {
      Vector3d x = B.col(i);
      Vector3d norm = N.col(i);
      VectorXd v(6);
      v.start(3) = x.cross(norm);
      v.end(3) = norm;
      double d = (x-A.col(i)).dot(norm);

      double df = v.dot(delta)+d;

      if(df <= EPSILON)
      {
	fx += df*df/2/EPSILON;
	g += (v*v.transpose()*delta+d*v)/EPSILON;
      }
      else
      {
	fx += df-EPSILON/2;
	g += (v*v.transpose()*delta+d*v)/df;
      }
    }
  }

  for(int i = 0 ; i < 6 ; i++)
  {
    grad[i] = g(i);
  }

  return fx;
}

static int progressHuber(
    void *instance,
    const lbfgsfloatval_t *x,
    const lbfgsfloatval_t *g,
    const lbfgsfloatval_t fx,
    const lbfgsfloatval_t xnorm,
    const lbfgsfloatval_t gnorm,
    const lbfgsfloatval_t step,
    int n,
    int k,
    int ls
    )
{
  if(HUBERPARAM.VERBOSE)
  {
    printf("Iteration %d:\n", k);
    printf("  fx = %f, xnorm = %f, gnorm = %f, step = %f\n", fx, xnorm, gnorm, step);
    printf("\n");
  }
  return 0;
}

////////////////////////////////////////////////////////////////////////////////
void PointL2(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();
  Vector3d mu_x = B.rowwise().sum()/n;
  Vector3d mu_y = A.rowwise().sum()/n;

  Matrix3d C = A*B.transpose();
  SVD<Matrix3d> svd(C);
  MatrixXd S = MatrixXd::Identity(3,3);
  if(C.determinant()<0)
  {
    S(2,2) = -1;
  }
  R = svd.matrixU()*S*svd.matrixV().transpose();
  t = mu_y - R*mu_x;

  return;
}

void PointL2T(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  VectorXd g(6);
  MatrixXd H(6,6);
  g.setZero();
  H.setZero();

  int n = A.cols();
  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d y = A.col(i);
    Vector3d d = x-y;
    MatrixXd V(3,6);
    V.block(0,3,3,3) = Matrix3d::Identity();
    V.block(0,0,3,3) = -cross2Skew(x);

    g += V.transpose()*d;
    H += V.transpose()*V;
  }

  H.ldlt().solveInPlace(g);
  VectorXd delta = -g;

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PointRW(double p,const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();
  MatrixXd E = B-A;
  E = E.cwise().square();
  VectorXd d2 = E.colwise().sum();
  VectorXd w = d2.cwise().pow((p-2)/2);

  Matrix3d C = A*w.asDiagonal()*B.transpose();
  SVD<Matrix3d> svd(C);
  MatrixXd S = MatrixXd::Identity(3,3);
  if(C.determinant()<0)
  {
    S(2,2) = -1;
  }
  R = svd.matrixU()*S*svd.matrixV().transpose();

  MatrixXd RB = R*B;
  double w_sum = w.sum();
  Vector3d mu_x = (RB*w.asDiagonal()).rowwise().sum()/w_sum;
  Vector3d mu_y = (A*w.asDiagonal()).rowwise().sum()/w_sum;

  t = mu_y - mu_x;

  return;
}

void PointRWT(double p,const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  VectorXd g(6);
  MatrixXd H(6,6);
  g.setZero();
  H.setZero();

  double dm = (p-2)/2;
  int n = A.cols();
  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d y = A.col(i);
    Vector3d d = x-y;
    MatrixXd V(3,6);
    V.block(0,3,3,3) = Matrix3d::Identity();
    V.block(0,0,3,3) = -cross2Skew(x);

    double w = pow(d.squaredNorm(),dm);

    g += w*V.transpose()*d;
    H += w*V.transpose()*V;
  }

  H.ldlt().solveInPlace(g);
  VectorXd delta = -g;

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PointL1(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  SDPASparse sdp;
  sdp.varnum = 6+n;
  sdp.blocknum = n;
  sdp.object.resize(6+n);
  sdp.blockstruct.resize(n);
  for(int i = 0 ; i < 6 ; i++)
  {
    sdp.object[i] = 0;
  }
  sdp.object[6] = 1;
  sdp.matices.resize(6+1+n);

  struct sparseblock *preblockptr[7];

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d y = A.col(i);
    Vector3d d = x-y;
    MatrixXd V(3,6);
    V.block(0,3,3,3) = Matrix3d::Identity();
    V.block(0,0,3,3) = -cross2Skew(x);

    sdp.object[i+6] = 1;
    sdp.blockstruct[i] = 4;

    for(int j = 0 ; j < 6 ; j++)
    {
      SparseSymMatrix mat(3);
      for(int k = 0 ; k < 3 ; k++)
      {
	mat.iindices[k] = k+1;
	mat.jindices[k] = 4;
	mat.entries[k] = V(k,j);
      }
      sdp.matices[j+1].push_back(SDPASparse::BlockMatrix(i+1,mat));
    }

    SparseSymMatrix mati(4);
    for(int k = 0 ; k < 4 ; k++)
    {
      mati.iindices[k] = k+1;
      mati.jindices[k] = k+1;
      mati.entries[k] = 1;
    }
    sdp.matices[6+1+i].push_back(SDPASparse::BlockMatrix(i+1,mati));

    SparseSymMatrix mat0(3);
    for(int k = 0 ; k < 3 ; k++)
    {
      mat0.iindices[k] = k+1;
      mat0.jindices[k] = 4;
      mat0.entries[k] = -d(k);
    }
    sdp.matices[0].push_back(SDPASparse::BlockMatrix(i+1,mat0));
  }

  sdp.write("prob.dat-s");

  system ("csdp prob.dat-s prob.res");  

  VectorXd delta(6);
  vector<double> y = SDPASparse::readCSDPSol("prob.res",6);
  for(int i = 0 ; i < 6 ; i++)
  {
    delta(i) = y[i];
  }

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PointLi(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  SDPASparse sdp;
  sdp.varnum = 7;
  sdp.blocknum = n;
  sdp.object.resize(7);
  sdp.blockstruct.resize(n);
  for(int i = 0 ; i < 6 ; i++)
  {
    sdp.object[i] = 0;
  }
  sdp.object[6] = 1;
  sdp.matices.resize(7+1);

  struct sparseblock *preblockptr[7];

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d y = A.col(i);
    Vector3d d = x-y;
    MatrixXd V(3,6);
    V.block(0,3,3,3) = Matrix3d::Identity();
    V.block(0,0,3,3) = -cross2Skew(x);

    sdp.blockstruct[i] = 4;

    for(int j = 0 ; j < 7 ; j++)
    {
      if(j < 6)
      {
	SparseSymMatrix mat(3);
	for(int k = 0 ; k < 3 ; k++)
	{
	  mat.iindices[k] = k+1;
	  mat.jindices[k] = 4;
	  mat.entries[k] = V(k,j);
	}
	sdp.matices[j+1].push_back(SDPASparse::BlockMatrix(i+1,mat));
      }
      else
      {
	SparseSymMatrix mat(4);
	for(int k = 0 ; k < 4 ; k++)
	{
	  mat.iindices[k] = k+1;
	  mat.jindices[k] = k+1;
	  mat.entries[k] = 1;
	}
	sdp.matices[j+1].push_back(SDPASparse::BlockMatrix(i+1,mat));
      }
    }

    SparseSymMatrix mat0(3);
    for(int k = 0 ; k < 3 ; k++)
    {
      mat0.iindices[k] = k+1;
      mat0.jindices[k] = 4;
      mat0.entries[k] = -d(k);
    }
    sdp.matices[0].push_back(SDPASparse::BlockMatrix(i+1,mat0));
  }

  sdp.write("prob.dat-s");

  system ("csdp prob.dat-s prob.res");  

  VectorXd delta(6);
  vector<double> y = SDPASparse::readCSDPSol("prob.res",6);
  for(int i = 0 ; i < 6 ; i++)
  {
    delta(i) = y[i];
  }

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PointL1H(double epsilon,const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();
  lbfgsfloatval_t fx;
  lbfgsfloatval_t *x = lbfgs_malloc(6);
  lbfgs_parameter_t param;

  HUBERPARAM.TYPE = HuberParam::POINT;
  HUBERPARAM.A = A;
  HUBERPARAM.B = B;
  HUBERPARAM.EPSILON = epsilon;
  HUBERPARAM.VERBOSE = false;

  /* Initialize the variables. */
  for(int i = 0 ; i < 6 ; i++)
  {
    x[i] = 0;
  }

  /* Initialize the parameters for the L-BFGS optimization. */
  lbfgs_parameter_init(&param);

  int ret = lbfgs(6, x, &fx, evaluateHuber, progressHuber, NULL, &param);

  if(ret != 0)
  {
    param.linesearch = LBFGS_LINESEARCH_BACKTRACKING;
    ret = lbfgs(6, x, &fx, evaluateHuber, progressHuber, NULL, &param);
  }

  if(ret != 0)
  {
    cerr<<"Optimization failed!"<<endl;
  }

  VectorXd delta(6);
  for(int i = 0 ; i < 6 ; i++)
  {
    delta(i) = x[i];
  }

  R = IR2R(delta.start(3));
  t = delta.end(3);

  lbfgs_free(x);

  return;
}

#ifdef MOSEK
void PointL1M(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  MSKenv_t env = NULL;
  MSKtask_t task = NULL;
  MSKrescodee res;

  res = MSK_makeenv(&env,NULL,NULL,NULL,NULL);
  if (res == MSK_RES_OK)
    res = MSK_initenv(env);
  if (res == MSK_RES_OK)
    res = MSK_maketask(env,0,0,&task);

  if (res == MSK_RES_OK)
  {
    MSK_putmaxnumvar(task,6+n+3*n);

    MSK_putmaxnumcon(task,3*n);
    MSK_putmaxnumanz(task,(1+6)*3*n);
    MSK_putmaxnumcone(task,n);

    MSK_append(task,MSK_ACC_VAR,6+n+3*n);
    MSK_append(task,MSK_ACC_CON,3*n);

    for(int i = 0 ; i < 6 ; i++)
    {
      MSK_putbound(task,MSK_ACC_VAR,i,MSK_BK_FR,0,0);
      MSK_putcj(task,i,0);
    }

    for(int i = 0 ; i < 3*n ; i++)
    {
      MSK_putbound(task,MSK_ACC_VAR,6+n+i,MSK_BK_FR,0,0);
      MSK_putcj(task,6+n+i,0);
    }
  }

  MSKidxt csub[4];

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d y = A.col(i);
    Vector3d d = x-y;
    MatrixXd V(3,6);
    V.block(0,3,3,3) = Matrix3d::Identity();
    V.block(0,0,3,3) = -cross2Skew(x);

    MSK_putbound(task,MSK_ACC_VAR,i+6,MSK_BK_LO,0,0);
    MSK_putcj(task,i+6,1);

    for(int j = 0 ; j < 3 ; j++)
    {
      for(int k = 0 ; k < 6 ; k++)
      {
	MSK_putaij(task,3*i+j,k,V(j,k));
      }
      MSK_putaij(task,3*i+j,6+n+3*i+j,-1);

      MSK_putbound(task,MSK_ACC_CON,3*i+j,MSK_BK_FX,-d(j),-d(j));
    }

    csub[0] = i+6;
    csub[1] = 6+n+3*i; 
    csub[2] = 6+n+3*i+1; 
    csub[3] = 6+n+3*i+2;
    MSK_appendcone(task,MSK_CT_QUAD,0,4,csub);
  }

  res = MSK_optimize(task);

  VectorXd delta(6);
  if (res == MSK_RES_OK)
  {
    MSKsolstae solsta;
    MSK_getsolutionstatus (task,MSK_SOL_ITR,NULL,&solsta);
    if(solsta == MSK_SOL_STA_OPTIMAL || solsta == MSK_SOL_STA_NEAR_OPTIMAL)
    {
      double xx[6];
      MSK_getsolutionslice(task,MSK_SOL_ITR,MSK_SOL_ITEM_XX,0,6,xx);

      for(int j = 0 ; j < 6 ; j++)
      {
	delta[j] = xx[j];
      }
    }
    else
    {
      cerr<<"Optimization failed!"<<endl;
    }
  }

  MSK_deletetask(&task);
  MSK_deleteenv(&env);  

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PointLiM(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  MSKenv_t env = NULL;
  MSKtask_t task = NULL;
  MSKrescodee res;

  res = MSK_makeenv(&env,NULL,NULL,NULL,NULL);
  if (res == MSK_RES_OK)
    res = MSK_initenv(env);
  if (res == MSK_RES_OK)
    res = MSK_maketask(env,0,0,&task);

  if (res == MSK_RES_OK)
  {
    MSK_putmaxnumvar(task,6+1+3*n);

    MSK_putmaxnumcon(task,3*n);
    MSK_putmaxnumanz(task,(1+6)*3*n);
    MSK_putmaxnumcone(task,n);

    MSK_append(task,MSK_ACC_VAR,6+1+3*n);
    MSK_append(task,MSK_ACC_CON,3*n);

    for(int i = 0 ; i < 6 ; i++)
    {
      MSK_putbound(task,MSK_ACC_VAR,i,MSK_BK_FR,0,0);
      MSK_putcj(task,i,0);
    }

    MSK_putbound(task,MSK_ACC_VAR,6,MSK_BK_LO,0,0);
    MSK_putcj(task,6,1);

    for(int i = 0 ; i < 3*n ; i++)
    {
      MSK_putbound(task,MSK_ACC_VAR,6+1+i,MSK_BK_FR,0,0);
      MSK_putcj(task,6+1+i,0);
    }
  }

  MSKidxt csub[4];

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d y = A.col(i);
    Vector3d d = x-y;
    MatrixXd V(3,6);
    V.block(0,3,3,3) = Matrix3d::Identity();
    V.block(0,0,3,3) = -cross2Skew(x);

    for(int j = 0 ; j < 3 ; j++)
    {
      for(int k = 0 ; k < 6 ; k++)
      {
	MSK_putaij(task,3*i+j,k,V(j,k));
      }
      MSK_putaij(task,3*i+j,6+1+3*i+j,-1);

      MSK_putbound(task,MSK_ACC_CON,3*i+j,MSK_BK_FX,-d(j),-d(j));
    }

    csub[0] = 6;
    csub[1] = 6+1+3*i; 
    csub[2] = 6+1+3*i+1; 
    csub[3] = 6+1+3*i+2;
    MSK_appendcone(task,MSK_CT_QUAD,0,4,csub);
  }

  res = MSK_optimize(task);

  VectorXd delta(6);
  if (res == MSK_RES_OK)
  {
    MSKsolstae solsta;
    MSK_getsolutionstatus (task,MSK_SOL_ITR,NULL,&solsta);
    if(solsta == MSK_SOL_STA_OPTIMAL || solsta == MSK_SOL_STA_NEAR_OPTIMAL)
    {
      double xx[6];
      MSK_getsolutionslice(task,MSK_SOL_ITR,MSK_SOL_ITEM_XX,0,6,xx);

      for(int j = 0 ; j < 6 ; j++)
      {
	delta[j] = xx[j];
      }
    }
    else
    {
      cerr<<"Optimization failed!"<<endl;
    }
  }

  MSK_deletetask(&task);
  MSK_deleteenv(&env);  

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}
#endif
///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////

void PlaneL2(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  VectorXd g(6);
  MatrixXd H(6,6);
  g.setZero();
  H.setZero();

  int n = A.cols();
  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d norm = N.col(i);
    VectorXd v(6);
    v.start(3) = x.cross(norm);
    v.end(3) = norm;
    double d = (x-A.col(i)).dot(norm);

    g += d*v;
    H += v*v.transpose();
  }

  H.ldlt().solveInPlace(g);
  VectorXd delta = -g;

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PlaneRW(double p,const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  VectorXd g(6);
  MatrixXd H(6,6);
  g.setZero();
  H.setZero();

  int n = A.cols();
  double dm = p-2;
  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d norm = N.col(i);
    VectorXd v(6);
    v.start(3) = x.cross(norm);
    v.end(3) = norm;
    double d = (x-A.col(i)).dot(norm);

    double w = pow(abs(d),dm);
    g += w*d*v;
    H += w*v*v.transpose();
  }

  H.ldlt().solveInPlace(g);
  VectorXd delta = -g;

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PlaneL1(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  glp_prob *lp = glp_create_prob();
  glp_set_obj_dir(lp, GLP_MIN);
  glp_add_rows(lp, 2*n);
  glp_add_cols(lp, 6+n);
  int* ia = new int[1+7*2*n];
  int* ja = new int[1+7*2*n];
  double* ar = new double[1+7*2*n];
  for(int i = 1 ; i < 7 ; i++)
  {
    glp_set_col_bnds(lp, i ,GLP_FR, 0, 0);
    glp_set_obj_coef(lp, i, 0);
  }

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d n = N.col(i);
    VectorXd v(6);
    v.start(3) = x.cross(n);
    v.end(3) = n;
    double d = (x-A.col(i)).dot(n);

    glp_set_row_bnds(lp, 2*i+1, GLP_LO, -d, 0);
    glp_set_row_bnds(lp, 2*i+2, GLP_UP, 0, -d);
    glp_set_col_bnds(lp, i+7, GLP_LO, 0, 0);
    glp_set_obj_coef(lp, i+7, 1);

    for(int j = 1 ; j < 7 ; j++)
    {
      ia[14*i+j] = 2*i+1;
      ja[14*i+j] = j;
      ar[14*i+j] = v(j-1);

      ia[14*i+7+j] = 2*i+2;
      ja[14*i+7+j] = j;
      ar[14*i+7+j] = v(j-1);
    }
    ia[14*i+7] = 2*i+1;
    ja[14*i+7] = i+7;
    ar[14*i+7] = 1;
    ia[14*i+14] = 2*i+2;
    ja[14*i+14] = i+7;
    ar[14*i+14] = -1;
  }

  glp_load_matrix(lp, 14*n, ia, ja, ar);
  glp_term_out(GLP_OFF);
  if(glp_simplex(lp, NULL) != 0)
  {
    cerr<<"Optimization failed!"<<endl;
  }

  VectorXd delta(6);
  for(int i = 1 ; i < 7 ; i++)
  {
    delta(i-1) = glp_get_col_prim(lp, i);
  }

  glp_delete_prob(lp);
  delete [] ia;
  delete [] ja;
  delete [] ar;

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PlaneLi(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  glp_prob *lp = glp_create_prob();
  glp_set_obj_dir(lp, GLP_MIN);
  glp_add_rows(lp, 2*n);
  glp_add_cols(lp, 6+1);
  int* ia = new int[1+7*2*n];
  int* ja = new int[1+7*2*n];
  double* ar = new double[1+7*2*n];
  for(int i = 1 ; i < 7 ; i++)
  {
    glp_set_col_bnds(lp, i ,GLP_FR, 0, 0);
    glp_set_obj_coef(lp, i, 0);
  }
  glp_set_col_bnds(lp, 7, GLP_LO, 0, 0);
  glp_set_obj_coef(lp, 7, 1);

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d norm = N.col(i);
    VectorXd v(6);
    v.start(3) = x.cross(norm);
    v.end(3) = norm;
    double d = (x-A.col(i)).dot(norm);

    glp_set_row_bnds(lp, 2*i+1, GLP_LO, -d, 0);
    glp_set_row_bnds(lp, 2*i+2, GLP_UP, 0, -d);

    for(int j = 1 ; j < 7 ; j++)
    {
      ia[14*i+j] = 2*i+1;
      ja[14*i+j] = j;
      ar[14*i+j] = v(j-1);

      ia[14*i+7+j] = 2*i+2;
      ja[14*i+7+j] = j;
      ar[14*i+7+j] = v(j-1);
    }
    ia[14*i+7] = 2*i+1;
    ja[14*i+7] = 7;
    ar[14*i+7] = 1;
    ia[14*i+14] = 2*i+2;
    ja[14*i+14] = 7;
    ar[14*i+14] = -1;
  }

  glp_load_matrix(lp, 14*n, ia, ja, ar);
  glp_write_mps(lp,GLP_MPS_DECK,NULL,"glpk.mps.gz");  
  glp_term_out(GLP_OFF);
  if(glp_simplex(lp, NULL) != 0)
  {
    cerr<<"Optimization failed!"<<endl;
  }

  VectorXd delta(6);
  for(int i = 1 ; i < 7 ; i++)
  {
    delta(i-1) = glp_get_col_prim(lp, i);
  }

  glp_delete_prob(lp);
  delete [] ia;
  delete [] ja;
  delete [] ar;

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PlaneL1H(double epsilon,const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();
  lbfgsfloatval_t fx;
  lbfgsfloatval_t *x = lbfgs_malloc(6);
  lbfgs_parameter_t param;

  HUBERPARAM.TYPE = HuberParam::PLANE;
  HUBERPARAM.A = A;
  HUBERPARAM.B = B;
  HUBERPARAM.N = N;
  HUBERPARAM.EPSILON = epsilon;
  HUBERPARAM.VERBOSE = false;

  /* Initialize the variables. */
  for(int i = 0 ; i < 6 ; i++)
  {
    x[i] = 0;
  }

  /* Initialize the parameters for the L-BFGS optimization. */
  lbfgs_parameter_init(&param);

  int ret = lbfgs(6, x, &fx, evaluateHuber, progressHuber, NULL, &param);

  if(ret != 0)
  {
    param.linesearch = LBFGS_LINESEARCH_BACKTRACKING;
    ret = lbfgs(6, x, &fx, evaluateHuber, progressHuber, NULL, &param);
  }

  if(ret != 0)
  {
    cerr<<"Optimization failed!"<<endl;
  }

  VectorXd delta(6);
  for(int i = 0 ; i < 6 ; i++)
  {
    delta(i) = x[i];
  }

  R = IR2R(delta.start(3));
  t = delta.end(3);

  lbfgs_free(x);

  return;
}

#ifdef MOSEK
void PlaneL1M(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  MSKenv_t env = NULL;
  MSKtask_t task = NULL;
  MSKrescodee res;

  res = MSK_makeenv(&env,NULL,NULL,NULL,NULL);
  if (res == MSK_RES_OK)
    res = MSK_initenv(env);
  if (res == MSK_RES_OK)
    res = MSK_maketask(env,0,0,&task);

  if (res == MSK_RES_OK)
  {
    MSK_putmaxnumvar(task,6+n);

    MSK_putmaxnumcon(task,2*n);
    MSK_putmaxnumanz(task,(1+6)*2*n);

    MSK_append(task,MSK_ACC_VAR,6+n);
    MSK_append(task,MSK_ACC_CON,2*n);

    for(int i = 0 ; i < 6 ; i++)
    {
      MSK_putbound(task,MSK_ACC_VAR,i,MSK_BK_FR,0,0);
      MSK_putcj(task,i,0);
    }
  }

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d norm = N.col(i);
    VectorXd v(6);
    v.start(3) = x.cross(norm);
    v.end(3) = norm;
    double d = (x-A.col(i)).dot(norm);

    MSK_putbound(task,MSK_ACC_VAR,i+6,MSK_BK_LO,0,0);
    MSK_putcj(task,i+6,1);

    for(int j = 0 ; j < 6 ; j++)
    {
      MSK_putaij(task,2*i,j,v(j));
      MSK_putaij(task,2*i+1,j,v(j));
    }

    MSK_putaij(task,2*i,6+i,1);
    MSK_putaij(task,2*i+1,6+i,-1);

    MSK_putbound(task,MSK_ACC_CON,2*i,MSK_BK_LO,-d,0);
    MSK_putbound(task,MSK_ACC_CON,2*i+1,MSK_BK_UP,0,-d);
  }

  res = MSK_optimize(task);

  VectorXd delta(6);
  if (res == MSK_RES_OK)
  {
    MSKsolstae solsta;
    MSK_getsolutionstatus (task,MSK_SOL_ITR,NULL,&solsta);
    if(solsta == MSK_SOL_STA_OPTIMAL || solsta == MSK_SOL_STA_NEAR_OPTIMAL)
    {
      double xx[6];
      MSK_getsolutionslice(task,MSK_SOL_ITR,MSK_SOL_ITEM_XX,0,6,xx);

      for(int j = 0 ; j < 6 ; j++)
      {
	delta[j] = xx[j];
      }
    }
    else
    {
      cerr<<"Optimization failed!"<<endl;
    }
  }

  MSK_deletetask(&task);
  MSK_deleteenv(&env);  

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}

void PlaneLiM(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t)
{
  int n = A.cols();

  MSKenv_t env = NULL;
  MSKtask_t task = NULL;
  MSKrescodee res;

  res = MSK_makeenv(&env,NULL,NULL,NULL,NULL);
  if (res == MSK_RES_OK)
    res = MSK_initenv(env);
  if (res == MSK_RES_OK)
    res = MSK_maketask(env,0,0,&task);

  //MSK_linkfunctotaskstream (task , MSK_STREAM_LOG ,NULL , printstr );

  if (res == MSK_RES_OK)
  {
    MSK_putmaxnumvar(task,6+1);

    MSK_putmaxnumcon(task,2*n);
    MSK_putmaxnumanz(task,(1+6)*2*n);

    MSK_append(task,MSK_ACC_VAR,6+1);
    MSK_append(task,MSK_ACC_CON,2*n);

    for(int i = 0 ; i < 6 ; i++)
    {
      MSK_putbound(task,MSK_ACC_VAR,i,MSK_BK_FR,0,0);
      MSK_putcj(task,i,0);
    }

    MSK_putbound(task,MSK_ACC_VAR,6,MSK_BK_LO,0,0);
    MSK_putcj(task,6,1);
  }

  for(int i = 0 ; i < n ; i++)
  {
    Vector3d x = B.col(i);
    Vector3d norm = N.col(i);
    VectorXd v(6);
    v.start(3) = x.cross(norm);
    v.end(3) = norm;
    double d = (x-A.col(i)).dot(norm);

    for(int j = 0 ; j < 6 ; j++)
    {
      MSK_putaij(task,2*i,j,v(j));
      MSK_putaij(task,2*i+1,j,v(j));
    }

    MSK_putaij(task,2*i,6,1);
    MSK_putaij(task,2*i+1,6,-1);

    MSK_putbound(task,MSK_ACC_CON,2*i,MSK_BK_LO,-d,0);
    MSK_putbound(task,MSK_ACC_CON,2*i+1,MSK_BK_UP,0,-d);
  }

  //MSK_writedata(task,"mosek.mps.gz");
  res = MSK_optimize(task);
  MSK_solutionsummary(task,MSK_STREAM_LOG);

  VectorXd delta(6);
  if (res == MSK_RES_OK)
  {
    MSKsolstae solsta;
    MSK_getsolutionstatus (task,MSK_SOL_ITR,NULL,&solsta);
    if(solsta == MSK_SOL_STA_OPTIMAL || solsta == MSK_SOL_STA_NEAR_OPTIMAL)
    {
      double xx[6];
      MSK_getsolutionslice(task,MSK_SOL_ITR,MSK_SOL_ITEM_XX,0,6,xx);

      for(int j = 0 ; j < 6 ; j++)
      {
	delta[j] = xx[j];
      }
    }
    else
    {
      cerr<<"Optimization failed!"<<endl;
    }
  }

  MSK_deletetask(&task);
  MSK_deleteenv(&env);  

  R = IR2R(delta.start(3));
  t = delta.end(3);

  return;
}
#endif
