#include <Eigen/Dense>
using namespace Eigen;

//////////////////////////////////////////////////////////
//Parameters:
//A: 3*n matrix representing objective pointset.
//B: 3*n matrix representing moving pointset.
//N: 3*n matrix representing normals corresponding to A.
//R: rotation matrix.
//t: translation vector.
//p: p-norm regression with IRLS
//epsilon: the parameter of Huber function
//////////////////////////////////////////////////////////

////////////////////////////////////////
//Point-to-Point distance optimization//
////////////////////////////////////////

//L2 optimization, i.e. origin ICP
void PointL2(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L2 optimization with infinitesimal transformation approximation
void PointL2T(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L1 optimization
void PointL1(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L_\infty optimization
void PointLi(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//p-norm regression with Iterative Reweighted Least Square(IRLS)
void PointRW(double p,const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//p-norm regression with Iterative Reweighted Least Square(IRLS) and infinitesimal transformation approximation
void PointRWT(double p,const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L1 optimization, approximated with Huber function
void PointL1H(double epsilon,const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

#ifdef MOSEK
//L1 optimization, using Mosek
void PointL1M(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L_\infty optimization, using Mosek
void PointLiM(const MatrixXd& A,const MatrixXd& B,Matrix3d& R,Vector3d& t);
#endif
////////////////////////////////////////
//Point-to-Plain distance optimization//
////////////////////////////////////////

//L2 optimization, i.e. Chen's method
void PlaneL2(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L1 optimization
void PlaneL1(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L_\infty optimization
void PlaneLi(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//p-norm regression with Iterative Reweighted Least Square(IRLS)
void PlaneRW(double p,const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L1 optimization, approximated with Huber function
void PlaneL1H(double epsilon,const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t);

#ifdef MOSEK
//L1 optimization, using Mosek
void PlaneL1M(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t);

//L_\infty optimization, using Mosek
void PlaneLiM(const MatrixXd& A,const MatrixXd N,const MatrixXd& B,Matrix3d& R,Vector3d& t);
#endif
