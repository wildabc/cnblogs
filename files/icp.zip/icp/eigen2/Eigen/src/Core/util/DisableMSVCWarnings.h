
#ifdef _MSC_VER
  // 4273 - QtAlignedMalloc, inconsistent dll linkage
  #pragma warning( push )
  #pragma warning( disable : 4181 4244 4127 4211 4273 4522 4717 )
#endif
